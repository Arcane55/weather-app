# Copilot Instructions for Weather App

## Project Overview
This is a simple weather application that fetches current weather data from the OpenWeatherMap API and displays it in a web browser. The app is built with vanilla HTML, CSS, and JavaScript - no frameworks or build tools required.

## Architecture
- **Major components**: 
  - `index.html`: Main page structure with input form and weather display area
  - `script.js`: Handles API calls and DOM updates
  - `styles.css`: Basic responsive styling
- **Data flows**: User enters city name → JavaScript fetches from OpenWeatherMap API → Parses JSON response → Updates DOM with weather info (temperature, description, humidity, icon)
- **Service boundaries**: Pure client-side application with no backend; all logic in browser JavaScript

## Developer Workflows
- **Build**: No build process - static files served directly
- **Test**: Open `index.html` in browser; test with different city names
- **Debug**: Use browser dev tools; check console for API errors; API responses logged implicitly via fetch
- **Run locally**: `python -m http.server 8000` or `live-server` for development server

## Conventions and Patterns
- **API integration**: Uses `fetch()` with async/await for HTTP requests (see `fetchWeather()` in `script.js`); error handling with try/catch blocks that display user-friendly messages in the DOM; no API key required for wttr.in
- **DOM manipulation**: Direct element selection by ID using `document.getElementById()` (e.g., `document.getElementById('city-input')`); dynamic content updates via `innerHTML` for weather display area
- **Styling**: Modern glassmorphism design with backdrop-filter blur; CSS gradients for backgrounds and buttons; flexbox grid for weather details; smooth animations with keyframes; Font Awesome icons for weather conditions and UI elements
- **Code structure**: Event listener attached to button click (`document.getElementById('get-weather').addEventListener('click', ...)`); separate functions for data fetching (`fetchWeather()`) and UI updates (`displayWeather()`); input validation with `trim()` and empty check
- **Input handling**: User input trimmed and validated for emptiness before API call; alert for invalid input
- **Error display**: Errors shown with Font Awesome icons and styled error messages
- **Data display**: Weather data in card-based grid layout with icons and animations; loading spinner during API calls; weather condition mapping to appropriate Font Awesome icons
- **PWA features**: Service worker registration for offline caching; web app manifest for installable app; responsive design for mobile/desktop installation

## Key Files
- `index.html`: Entry point with HTML structure and PWA manifest link
- `script.js`: Core logic - API calls, UI updates, and service worker registration
- `styles.css`: Visual styling and layout with modern CSS features
- `README.md`: Setup instructions and deployment guides
- `.gitignore`: Standard exclusions for version control
- `manifest.json`: PWA manifest for installable app
- `sw.js`: Service worker for offline caching

## Integration Points
- **wttr.in API**: Free API with no key required; endpoint: `https://wttr.in/{city}?format=j1`
- **External dependencies**: None (vanilla JS)